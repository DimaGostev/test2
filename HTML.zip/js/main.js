function back_panel() {
	var side_panel = document.getElementById('side_panel');
	var status = side_panel.style.left;
	if(status == '-100%'){side_panel.style.left = '0%'}
	else{side_panel.style.left = '-100%'}
}